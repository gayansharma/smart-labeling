def detect_defects(image_file):
    # Dummy logic
    return "No defects" if image_file else "Image not provided"