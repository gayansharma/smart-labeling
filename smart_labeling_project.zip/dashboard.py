import streamlit as st
from label_generator import generate_label
from quality_check import check_quality
from defect_detection import detect_defects
from database import insert_product, get_all_products

st.title("Smart Product Labeling & Traceability System")

product_name = st.text_input("Product Name")
batch_no = st.text_input("Batch Number")
temperature = st.slider("Temperature (°C)", 10, 100, 25)
weight = st.slider("Weight (g)", 50, 500, 250)
size = st.slider("Size (cm)", 1, 100, 50)

uploaded_file = st.file_uploader("Upload Product Image", type=["jpg", "png"])

if st.button("Check & Label"):
    quality_passed = check_quality(weight, temperature, size)
    defects = detect_defects(uploaded_file) if uploaded_file else "No image"

    if quality_passed and defects == "No defects":
        label_path = generate_label(product_name, batch_no)
        insert_product(product_name, batch_no, temperature, weight, size, label_path)
        st.success("Product Passed! Label Generated.")
        st.image(label_path)
    else:
        st.error("Product failed QC or has defects.")
        st.text(f"Quality Check: {'Passed' if quality_passed else 'Failed'}")
        st.text(f"Defect Detection: {defects}")

st.subheader("Traceability Records")
for row in get_all_products():
    st.write(row)