def check_quality(weight, temperature, size):
    return 100 <= weight <= 300 and 20 <= temperature <= 40 and 10 <= size <= 80